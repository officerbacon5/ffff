# Current Features

* support mysql-async
* configurable (features and language)
* cops whitelist
* take/break service (positions with blips)
* different service mode
* cop garage (vehicle/heli)
* check inventory (legacy feature)
* fines (legacy feature)
* cuff/uncuff (credits to @Marxy  : https://forum.fivem.net/t/release-simple-cuff-script-and-example-resource/4200)
* check inventory (legacy feature)
* illegal items removed (legacy feature)
* weapons removed (legacy feature)
* force cuffed player to go in the vehicle
* unseat this player (Thanks @Thefoxeur54 )
* GUI menu with some animations
* check vehicle plate (legacy feature)
* cops can see each other blips : (thanks @Scammer  -- https://forum.fivem.net/t/release-scammers-script-collection-09-03-17/3313)
* drag players (thanks @Frazzle and others : https://forum.fivem.net/t/release-drag-command/22174)
* ranks (example of use : cloackroom.lua line 12)
* so many other features ...
